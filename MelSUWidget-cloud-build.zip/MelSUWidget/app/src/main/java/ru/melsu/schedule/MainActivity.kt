package ru.melsu.schedule

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 36, 28, 28)
            setBackgroundColor(Color.rgb(24, 28, 37))
        }
        fun label(text: String, size: Float, color: Int, bold: Boolean = false): TextView = TextView(this).apply {
            this.text = text; textSize = size; setTextColor(color)
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, 0, 0, 18)
        }
        root.addView(label("Расписание МелГУ", 28f, Color.WHITE, true))
        root.addView(label("Группа: 2611-3601.1", 18f, Color.rgb(128, 200, 255), true))
        root.addView(label("Расписание работает по двум шаблонам со скриншотов: недели 9, 11, 13, 15, 17 используют вариант A; недели 10, 12, 14, 16, 18 — вариант B.", 16f, Color.LTGRAY))
        root.addView(label("Важно: расписание внесено по скриншотам и не синхронизируется с изменениями на сайте. Некоторые мелкие подписи на изображениях читаются не полностью, поэтому проверь аудитории и подгруппы перед тем, как полагаться на виджет.", 16f, Color.LTGRAY))
        val button = Button(this).apply { text = "Обновить виджет"; setOnClickListener { ScheduleWidgetProvider.updateAll(this@MainActivity) } }
        root.addView(button, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(label("Чтобы добавить: удерживай пустое место на главном экране → Виджеты → Расписание МелГУ.", 14f, Color.rgb(174, 184, 201)))
        setContentView(root)
    }
}

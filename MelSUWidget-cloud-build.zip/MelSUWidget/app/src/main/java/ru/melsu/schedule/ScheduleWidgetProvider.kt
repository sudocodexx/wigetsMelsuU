package ru.melsu.schedule

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.widget.RemoteViews
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.LocalTime
import java.time.temporal.ChronoUnit

/** Static alternating-week timetable transcribed from the two user screenshots.
 * Week 9 = template A; week 10 = template B; templates alternate through week 18.
 * This build does not fetch changes from the university website.
 */
class ScheduleWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { render(context, manager, it) }
    }

    companion object {
        private data class Lesson(val day: DayOfWeek, val start: String, val end: String,
                                  val subject: String, val room: String, val subgroup: String = "")

        private val weekA = listOf(
            Lesson(DayOfWeek.MONDAY, "11:00", "12:20", "Программирование", "6.202", "Подгр. 1"),
            Lesson(DayOfWeek.MONDAY, "12:40", "14:00", "Программирование", "6.204", "Подгр. 2"),
            Lesson(DayOfWeek.MONDAY, "12:40", "14:00", "История России", "6.101", "Практика"),
            Lesson(DayOfWeek.MONDAY, "14:10", "15:30", "Основы российской государственности", "4.210", "Практика"),
            Lesson(DayOfWeek.TUESDAY, "08:00", "09:20", "Математика", "5.112", "Практика"),
            Lesson(DayOfWeek.TUESDAY, "09:30", "10:50", "Архитектура вычислительных систем", "6.102", "Подгр. 1"),
            Lesson(DayOfWeek.TUESDAY, "11:00", "12:20", "Архитектура вычислительных систем", "6.204", "Подгр. 2"),
            Lesson(DayOfWeek.TUESDAY, "11:00", "12:20", "Операционные системы и среды", "6.102", "Подгр. 1"),
            Lesson(DayOfWeek.TUESDAY, "12:40", "14:00", "Математическая логика и теория алгоритмов", "6.308", "Практика"),
            Lesson(DayOfWeek.WEDNESDAY, "09:30", "10:50", "Введение в профессионально-педагогическую деятельность", "6.205", "Практика"),
            Lesson(DayOfWeek.WEDNESDAY, "11:00", "12:20", "Теория алгоритмов", "6.308", "Лекция"),
            Lesson(DayOfWeek.THURSDAY, "08:00", "09:20", "Введение в профессионально-педагогическую деятельность", "6.308", "Лекция"),
            Lesson(DayOfWeek.THURSDAY, "09:30", "10:50", "Архитектура вычислительных систем", "6.308", "Лекция"),
            Lesson(DayOfWeek.FRIDAY, "08:00", "09:20", "Теория алгоритмов", "6.204", "Подгр. 1"),
            Lesson(DayOfWeek.FRIDAY, "09:30", "10:50", "Математика", "5.113", "Лекция"),
            Lesson(DayOfWeek.FRIDAY, "12:40", "14:00", "Основы российской государственности", "25.105", "Лекция")
        )

        private val weekB = listOf(
            Lesson(DayOfWeek.MONDAY, "08:00", "09:20", "Основы российской государственности", "4.210", "Практика"),
            Lesson(DayOfWeek.MONDAY, "09:30", "10:50", "Физическая культура и спорт", "СПОРТ.комплекс (р-н Б.Хмельницкого, 1)", "Практика"),
            Lesson(DayOfWeek.MONDAY, "11:00", "12:20", "Математическая логика и теория алгоритмов", "6.308", "Практика"),
            Lesson(DayOfWeek.MONDAY, "12:40", "14:00", "Операционные системы и среды", "6.203", "Подгр. 1"),
            Lesson(DayOfWeek.MONDAY, "14:10", "15:30", "Операционные системы и среды", "6.204", "Подгр. 2"),
            Lesson(DayOfWeek.TUESDAY, "12:40", "14:00", "Программирование", "6.204", "Подгр. 1"),
            Lesson(DayOfWeek.TUESDAY, "12:40", "14:00", "Программирование", "6.203", "Подгр. 2"),
            Lesson(DayOfWeek.TUESDAY, "14:10", "15:30", "Основы российской государственности", "25.105", "Лекция"),
            Lesson(DayOfWeek.WEDNESDAY, "12:40", "14:00", "Теория алгоритмов", "6.201", "Подгр. 2"),
            Lesson(DayOfWeek.WEDNESDAY, "14:10", "15:30", "Операционные системы и среды", "6.308", "Лекция"),
            Lesson(DayOfWeek.WEDNESDAY, "15:40", "17:00", "Иностранный язык", "13.406", "Практика"),
            Lesson(DayOfWeek.THURSDAY, "08:00", "09:20", "Программирование", "6.308", "Лекция"),
            Lesson(DayOfWeek.THURSDAY, "09:30", "10:50", "История России", "4.210", "Практика"),
            Lesson(DayOfWeek.FRIDAY, "11:00", "12:20", "Архитектура вычислительных систем", "6.203", "Подгр. 1"),
            Lesson(DayOfWeek.FRIDAY, "12:40", "14:00", "Архитектура вычислительных систем", "6.204", "Подгр. 2"),
            Lesson(DayOfWeek.FRIDAY, "12:40", "14:00", "Математическая логика и теория алгоритмов", "6.308", "Лекция"),
            Lesson(DayOfWeek.FRIDAY, "14:10", "15:30", "История России", "25.105", "Лекция")
        )

        fun updateAll(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, ScheduleWidgetProvider::class.java))
            ids.forEach { render(context, manager, it) }
        }

        // The screenshots identify Monday 26 Oct 2026 as week 9.
        private fun weekFor(date: LocalDate): Int {
            val monday = date.with(DayOfWeek.MONDAY)
            val anchor = LocalDate.of(2026, 10, 26)
            return 9 + ChronoUnit.WEEKS.between(anchor, monday).toInt()
        }

        private fun render(context: Context, manager: AppWidgetManager, id: Int) {
            val views = RemoteViews(context.packageName, R.layout.widget_schedule)
            val today = LocalDate.now()
            val week = weekFor(today)
            if (week !in 9..18) {
                views.setTextViewText(R.id.widget_subject, "Семестр вне недель 9–18")
                views.setTextViewText(R.id.widget_time, "Текущая неделя: $week")
                views.setTextViewText(R.id.widget_room, "Шаблоны настроены для недель 9–18")
                views.setTextViewText(R.id.widget_week, "Группа 2611-3601.1")
                manager.updateAppWidget(id, views)
                return
            }
            val template = if (week % 2 == 1) weekA else weekB
            val now = LocalTime.now()
            val next = template.sortedWith(compareBy<Lesson>({ it.day.value }, { LocalTime.parse(it.start) }))
                .firstOrNull { it.day.value > today.dayOfWeek.value ||
                    (it.day == today.dayOfWeek && LocalTime.parse(it.start) >= now) }
            if (next == null) {
                views.setTextViewText(R.id.widget_subject, "Занятия на сегодня закончились")
                views.setTextViewText(R.id.widget_time, "Неделя $week · ${today.dayOfWeek.russian()}")
                views.setTextViewText(R.id.widget_room, "Следующая пара — в ближайший учебный день")
            } else {
                val number = when (next.start) {
                    "08:00" -> "1-я"; "09:30" -> "2-я"; "11:00" -> "3-я"
                    "12:40" -> "4-я"; "14:10" -> "5-я"; "15:40" -> "6-я"; else -> "Пара"
                }
                views.setTextViewText(R.id.widget_subject, next.subject)
                views.setTextViewText(R.id.widget_time, "$number пара · ${next.start}–${next.end}")
                val room = if (next.room.matches(Regex("\\d+\\.\\d+")))
                    "Корпус ${next.room.substringBefore('.')} · аудитория ${next.room.substringAfter('.')}" else next.room
                views.setTextViewText(R.id.widget_room, "⌖ $room${if (next.subgroup.isNotBlank()) " · ${next.subgroup}" else ""}")
            }
            views.setTextViewText(R.id.widget_week, "Неделя $week · ${if (week % 2 == 1) "вариант A" else "вариант B"} · 2611-3601.1")
            manager.updateAppWidget(id, views)
        }

        private fun DayOfWeek.russian() = when (this) {
            DayOfWeek.MONDAY -> "понедельник"; DayOfWeek.TUESDAY -> "вторник";
            DayOfWeek.WEDNESDAY -> "среда"; DayOfWeek.THURSDAY -> "четверг";
            DayOfWeek.FRIDAY -> "пятница"; DayOfWeek.SATURDAY -> "суббота"; DayOfWeek.SUNDAY -> "воскресенье"
        }
    }
}
